#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
  int readcount = getreadcount();
  printf(1, "Numbers of read count: %d\n", readcount);
  exit();
}
